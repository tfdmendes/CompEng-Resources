//
// Algoritmos e Estruturas de Dados --- 2024/2025
//
// Joaquim Madeira, May 2020, November 2023
//
// Hash Table using Open Addressing for COUNTING WORDS
// Keys are STRINGS - Values are INTEGERS
//

#ifndef _HASH_TABLE_
#define _HASH_TABLE_

typedef struct _HashTableHeader HashTable;

typedef unsigned int (*hashFunction)(const char* key);

typedef unsigned int (*probeFunction)(unsigned int index, unsigned int i,
                                      unsigned int size);

// Auxiliary functions for experimenting

unsigned int hash1(const char* key);
unsigned int hash2(const char* key);
unsigned int hash3(const char* key);

unsigned int linearProbing(unsigned int index, unsigned int i,
                           unsigned int size);
unsigned int quadraticProbing(unsigned int index, unsigned int i,
                              unsigned int size);

// TAD Functions

HashTable* HashTableCreate(unsigned int capacity, hashFunction hashF,
                           probeFunction probeF, int resizeIsEnabled);

void HashTableDestroy(HashTable** p);

// HashTable properties

int HashTableIsEmpty(const HashTable* hashT);

int HashTableIsFull(const HashTable* hashT);

// Getters

int HashTableGetNumberOfItems(const HashTable* hashT);

double HashTableGetLoadFactor(const HashTable* hashT);

// Operations with items

int HashTableContains(const HashTable* hashT, const char* key);

unsigned int HashTableGet(const HashTable* hashT, const char* key);

int HashTablePut(HashTable* hashT, const char* key, unsigned int value);

int HashTableIncrement(HashTable* hashT, const char* key);

int HashTableReplace(const HashTable* hashT, const char* key,
                     unsigned int value);

int HashTableRemove(HashTable* hashT, const char* key);

// DISPLAYING on the console

void HashTableDisplay(const HashTable* hashT);

void HashTableDisplayItems(const HashTable* hashT);

#endif  // _HASH_TABLE_
