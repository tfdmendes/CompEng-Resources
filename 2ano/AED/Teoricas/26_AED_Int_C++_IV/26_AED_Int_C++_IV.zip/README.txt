
Exemplos retirados do código disponibilizado por I. Horton.

E relativo ao livro "Beginning C++17 - From Novice to Professional".

São exemplos mais complexos do que os apresentados na aula.

Mas é sempre um bom exercício analisar o código (neste caso, mais profissional) desenvolvido por outros.

 

 