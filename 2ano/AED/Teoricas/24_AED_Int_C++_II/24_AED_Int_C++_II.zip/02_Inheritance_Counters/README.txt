
The value_ attibute of the base class is now protected -> Efficiency!

