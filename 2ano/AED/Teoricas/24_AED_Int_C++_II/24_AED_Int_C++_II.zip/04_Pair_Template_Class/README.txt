
If needed, compile with

g++ -Wall -Wextra -std=c++17 TestPairs.cpp Fraction.cpp