//
// Algoritmos e Estruturas de Dados --- 2024/2025
//
// Pointers LIST application example --- TO BE COMPLETED
//

#include "PointersList.h"

int main(void) { return 0; }