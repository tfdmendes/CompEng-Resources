
1 - Complete some of the missing functions on the .c file

2 - Develop a simple application example