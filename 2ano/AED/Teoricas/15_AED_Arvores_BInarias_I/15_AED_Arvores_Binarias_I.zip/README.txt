
BINARY TREE STORING INTEGER VALUES

FIRST INCOMPLETE VERSION 

TO DO :

1 - Compile and run the example

2 - Complete the missing code for some of the functions

REMARK : The tree traversals will be a topic of the next lecture

 